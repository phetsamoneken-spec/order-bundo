/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Product, Order, StoreProfile, ActiveTab } from './types/pos';
import {
  INITIAL_PRODUCTS,
  INITIAL_STORE_PROFILE,
  INITIAL_DEMO_ORDERS,
} from './data/initialData';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { Toast, ToastMessage } from './components/Toast';
import { GpsModal } from './components/GpsModal';
import { StoreSettingsModal } from './components/StoreSettingsModal';
import { MenuTab } from './components/tabs/MenuTab';
import { CartTab } from './components/tabs/CartTab';
import { DashboardTab } from './components/tabs/DashboardTab';
import { OrdersTab } from './components/tabs/OrdersTab';
import { CatalogTab } from './components/tabs/CatalogTab';
import { vibrateSoft } from './utils/formatters';
import { downloadStandaloneHtml } from './utils/exportSingleFile';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('pos-menu');

  // Products State with LocalStorage
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('lao_pos_products');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_PRODUCTS;
  });

  // Cart State with initial matching screenshot (2 Lao coffee, 1 Bubble tea, 1 Papaya salad = 108,000 Kip, 4 items)
  const [cart, setCart] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('lao_pos_cart');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return {
      'item-1': 2,
      'item-2': 1,
      'item-5': 1,
    };
  });

  // Orders State with LocalStorage
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('lao_pos_orders');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_DEMO_ORDERS;
  });

  // Store Profile State with LocalStorage
  const [profile, setProfile] = useState<StoreProfile>(() => {
    try {
      const saved = localStorage.getItem('lao_pos_profile');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return INITIAL_STORE_PROFILE;
  });

  // Toast notifications state
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // GPS Modal state
  const [isGpsModalOpen, setIsGpsModalOpen] = useState(false);

  // Store Settings (Name & Logo) Modal state
  const [isStoreSettingsOpen, setIsStoreSettingsOpen] = useState(false);

  // Sync to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('lao_pos_products', JSON.stringify(products));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem('lao_pos_cart', JSON.stringify(cart));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('lao_pos_orders', JSON.stringify(orders));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [orders]);

  useEffect(() => {
    try {
      localStorage.setItem('lao_pos_profile', JSON.stringify(profile));
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }, [profile]);

  // Toast notification dispatcher
  const showToast = (
    message: string,
    type: 'success' | 'info' | 'warning' | 'error' = 'info'
  ) => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, message, type }]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Cart Handlers
  const handleUpdateQty = (productId: string, delta: number) => {
    setCart((prev) => {
      const current = prev[productId] || 0;
      const next = current + delta;
      if (next <= 0) {
        const copy = { ...prev };
        delete copy[productId];
        return copy;
      }
      return { ...prev, [productId]: next };
    });
  };

  const handleSetQty = (productId: string, quantity: number) => {
    setCart((prev) => {
      if (quantity <= 0) {
        const copy = { ...prev };
        delete copy[productId];
        return copy;
      }
      return { ...prev, [productId]: Math.min(999, quantity) };
    });
  };

  const handleClearCart = () => {
    setCart({});
  };

  // Store Profile update
  const handleUpdateProfile = (updated: Partial<StoreProfile>) => {
    setProfile((prev) => ({ ...prev, ...updated }));
  };

  // Completed Order Handler
  const handleOrderCompleted = (newOrder: Order) => {
    setOrders((prev) => [newOrder, ...prev]);
  };

  // Catalog Handlers
  const handleAddProduct = (newProd: Product) => {
    setProducts((prev) => [newProd, ...prev]);
  };

  const handleDeleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    // Also remove from cart if present
    setCart((prev) => {
      if (prev[id]) {
        const copy = { ...prev };
        delete copy[id];
        return copy;
      }
      return prev;
    });
  };

  const handleResetProducts = () => {
    setProducts(INITIAL_PRODUCTS);
  };

  // Compute total cart item count for bottom badge
  const cartTotalCount = Object.values(cart).reduce((sum, q) => sum + q, 0);

  return (
    <div className="min-h-screen bg-[#faf8ff] text-[#131b2e] flex flex-col antialiased">
      {/* Toast Notification Container */}
      <Toast toasts={toasts} onDismiss={dismissToast} />

      {/* GPS Dialog Modal */}
      <GpsModal
        isOpen={isGpsModalOpen}
        onClose={() => setIsGpsModalOpen(false)}
        currentLat={profile.lat}
        currentLng={profile.lng}
        onUpdateLocation={(lat, lng) => handleUpdateProfile({ lat, lng })}
        onShowToast={showToast}
      />

      {/* Store Name & Logo Settings Modal */}
      <StoreSettingsModal
        isOpen={isStoreSettingsOpen}
        onClose={() => setIsStoreSettingsOpen(false)}
        profile={profile}
        onUpdateProfile={handleUpdateProfile}
        onShowToast={showToast}
      />

      {/* Fixed Top Header */}
      <Header
        activeTab={activeTab}
        profile={profile}
        onEditStore={() => {
          vibrateSoft();
          setIsStoreSettingsOpen(true);
        }}
        onOpenGpsModal={() => setIsGpsModalOpen(true)}
        onQuickSync={() => {
          vibrateSoft();
          showToast('⚡ ຂໍ້ມູນຖືກບັນທຶກ ແລະ ຊິງຄ໌ອອບໄລນ໌ແລ້ວ', 'success');
        }}
        onExportHtml={() => {
          vibrateSoft(20);
          downloadStandaloneHtml(profile.name);
          showToast('📥 ດາວໂຫລດໄຟລ໌ index.html Standalone ສຳເລັດແລ້ວ!', 'success');
        }}
      />

      {/* Main Content Area (padded top for fixed header) */}
      <main className="flex-1 w-full pt-16">
        {activeTab === 'pos-menu' && (
          <MenuTab
            products={products}
            cart={cart}
            onUpdateQty={handleUpdateQty}
            onSetQty={handleSetQty}
            onGoToCart={() => {
              vibrateSoft();
              setActiveTab('cart-and-whatsapp');
            }}
          />
        )}

        {activeTab === 'cart-and-whatsapp' && (
          <CartTab
            products={products}
            cart={cart}
            onUpdateQty={handleUpdateQty}
            onSetQty={handleSetQty}
            onClearCart={handleClearCart}
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            onOrderCompleted={handleOrderCompleted}
            onShowToast={showToast}
            onGoToMenu={() => {
              vibrateSoft();
              setActiveTab('pos-menu');
            }}
          />
        )}

        {activeTab === 'sales-dashboard' && (
          <DashboardTab orders={orders} products={products} />
        )}

        {activeTab === 'order-history' && (
          <OrdersTab
            orders={orders}
            onDeleteOrder={(id) => {
              setOrders((prev) => prev.filter((o) => o.id !== id));
            }}
            onClearAllOrders={() => {
              setOrders([]);
            }}
            profile={profile}
            onShowToast={showToast}
          />
        )}

        {activeTab === 'catalog-settings' && (
          <CatalogTab
            products={products}
            profile={profile}
            onOpenStoreSettings={() => {
              vibrateSoft();
              setIsStoreSettingsOpen(true);
            }}
            onAddProduct={handleAddProduct}
            onDeleteProduct={handleDeleteProduct}
            onResetProducts={handleResetProducts}
            onShowToast={showToast}
          />
        )}
      </main>

      {/* Fixed Bottom Dock Navigation */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        cartTotalCount={cartTotalCount}
      />
    </div>
  );
}
