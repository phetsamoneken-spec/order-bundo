export type ProductCategory = 'drinks' | 'food' | 'desserts';

export interface Product {
  id: string;
  name: string;
  nameEn: string;
  sub: string;
  category: ProductCategory;
  price: number;
  image: string;
  badgeText?: string;
  badgeType?: 'bestseller' | 'sweet' | 'recommended' | 'spicy' | 'custom';
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  createdAt: string; // ISO date string
  items: {
    productId: string;
    productName: string;
    productNameEn: string;
    category: ProductCategory;
    quantity: number;
    unitPrice: number;
  }[];
  subtotal: number;
  discount: number;
  total: number;
  storeName: string;
  customerName?: string;
  customerPhone?: string;
  ownerName?: string;
  cashierName?: string;
  contactPhone?: string;
  phone?: string;
  notes?: string;
  location?: {
    lat: number;
    lng: number;
  };
  storePhoto?: string;
  dispatchMode: 'group' | 'direct';
}

export interface StoreProfile {
  name: string;
  customerName?: string;
  customerPhone?: string;
  ownerName: string;
  cashierName?: string;
  phone: string;
  whatsappMode: 'group' | 'direct';
  whatsappTarget: string; // group or phone number
  lat: number;
  lng: number;
  photoUrl: string | null;
  logoUrl?: string | null;
  logoIcon?: string;
}

export type ActiveTab = 'pos-menu' | 'cart-and-whatsapp' | 'sales-dashboard' | 'order-history' | 'catalog-settings';
