import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';

interface LeafletMapProps {
  lat: number;
  lng: number;
  onPositionChange: (lat: number, lng: number) => void;
  height?: string;
}

export const LeafletMap: React.FC<LeafletMapProps> = ({
  lat,
  lng,
  onPositionChange,
  height = '200px',
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const currentLayersRef = useRef<L.Layer[]>([]);
  const [mapType, setMapType] = useState<'street' | 'satellite'>('street');

  // Helper to switch tile layers smoothly
  const applyTileLayers = (map: L.Map, type: 'street' | 'satellite') => {
    // Remove previous tile layers
    currentLayersRef.current.forEach((layer) => map.removeLayer(layer));
    currentLayersRef.current = [];

    if (type === 'satellite') {
      // ESRI High-Resolution Satellite Imagery (100% Free, No API Key, global coverage)
      const satLayer = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        {
          maxZoom: 19,
          attribution: '&copy; Esri World Imagery',
        }
      ).addTo(map);

      // Hybrid road and place label overlay for clarity
      const labelLayer = L.tileLayer(
        'https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
        {
          maxZoom: 19,
        }
      ).addTo(map);

      currentLayersRef.current = [satLayer, labelLayer];
    } else {
      // OpenStreetMap Standard Street Tiles (100% Free, No API Key, Lao labels)
      const osmLayer = L.tileLayer(
        'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        {
          maxZoom: 19,
          subdomains: ['a', 'b', 'c'],
          attribution: '&copy; OpenStreetMap contributors',
        }
      ).addTo(map);

      currentLayersRef.current = [osmLayer];
    }
  };

  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Initialize Leaflet map
      const map = L.map(mapContainerRef.current, {
        center: [lat, lng],
        zoom: 15,
        zoomControl: true,
        attributionControl: false,
      });

      // Apply initial tile layer
      applyTileLayers(map, mapType);

      // Create custom SVG Pin Icon with high contrast
      const customIcon = L.divIcon({
        className: 'custom-leaflet-pin',
        html: `
          <div style="position: relative; width: 36px; height: 44px; display: flex; align-items: center; justify-content: center; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.45));">
            <svg width="36" height="44" viewBox="0 0 36 44" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 0C8.05887 0 0 8.05887 0 18C0 28.5 15.5 42.5 17.1 43.8C17.6 44.2 18.4 44.2 18.9 43.8C20.5 42.5 36 28.5 36 18C36 8.05887 27.9411 0 18 0Z" fill="#006c49" stroke="#ffffff" stroke-width="1.5"/>
              <circle cx="18" cy="17" r="7" fill="white"/>
              <circle cx="18" cy="17" r="4.5" fill="#10b981"/>
            </svg>
          </div>
        `,
        iconSize: [36, 44],
        iconAnchor: [18, 44],
        popupAnchor: [0, -40],
      });

      const marker = L.marker([lat, lng], {
        draggable: true,
        icon: customIcon,
      }).addTo(map);

      marker.on('dragend', () => {
        const position = marker.getLatLng();
        onPositionChange(Number(position.lat.toFixed(5)), Number(position.lng.toFixed(5)));
      });

      map.on('click', (e) => {
        marker.setLatLng(e.latlng);
        onPositionChange(Number(e.latlng.lat.toFixed(5)), Number(e.latlng.lng.toFixed(5)));
      });

      mapInstanceRef.current = map;
      markerRef.current = marker;

      // Invalidate size to ensure clean render inside flex/tabs
      setTimeout(() => {
        map.invalidateSize();
      }, 200);
    } else {
      // Update existing map view & marker position
      mapInstanceRef.current.setView([lat, lng], mapInstanceRef.current.getZoom());
      if (markerRef.current) {
        markerRef.current.setLatLng([lat, lng]);
      }
    }
  }, [lat, lng, onPositionChange]);

  // Handle layer change when mapType changes
  useEffect(() => {
    if (mapInstanceRef.current) {
      applyTileLayers(mapInstanceRef.current, mapType);
    }
  }, [mapType]);

  // Handle map resize on re-render
  useEffect(() => {
    const timer = setTimeout(() => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.invalidateSize();
      }
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative w-full rounded-2xl overflow-hidden border border-emerald-900/15 shadow-sm">
      <div ref={mapContainerRef} style={{ height }} className="w-full bg-[#1b232a]" />
      
      {/* Real-time coordinates floating badge */}
      <div className="absolute top-2 left-2 z-[400] bg-black/75 backdrop-blur-md text-white text-[11px] font-display font-medium px-2.5 py-1 rounded-full shadow-md flex items-center gap-1.5 border border-white/20">
        <span className="w-2 h-2 rounded-full bg-[#10b981] animate-ping"></span>
        <span>{lat.toFixed(4)}, {lng.toFixed(4)}</span>
      </div>

      {/* Satellite / Street Map Toggle Switch */}
      <div className="absolute top-2 right-2 z-[400] bg-white/95 backdrop-blur-md p-0.5 rounded-xl shadow-md border border-black/10 flex items-center">
        <button
          type="button"
          onClick={() => setMapType('street')}
          className={`px-2 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all ${
            mapType === 'street'
              ? 'bg-[#006c49] text-white shadow-xs'
              : 'text-gray-600 hover:text-gray-900'
          }`}
          title="ແຜນທີ່ຖະໜົນ (Street View)"
        >
          <span className="material-symbols-outlined text-[14px]">map</span>
          <span>ຖະໜົນ</span>
        </button>

        <button
          type="button"
          onClick={() => setMapType('satellite')}
          className={`px-2 py-1 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-all ${
            mapType === 'satellite'
              ? 'bg-[#006c49] text-white shadow-xs'
              : 'text-gray-600 hover:text-gray-900'
          }`}
          title="ແຜນທີ່ດາວທຽມ (Satellite View)"
        >
          <span className="material-symbols-outlined text-[14px]">satellite_alt</span>
          <span>ດາວທຽມ</span>
        </button>
      </div>

      <div className="absolute bottom-2 right-2 z-[400] bg-white/90 backdrop-blur-md text-[#006c49] text-[10px] font-bold px-2 py-0.5 rounded-md shadow-xs border border-emerald-800/10 pointer-events-none">
        ລາກໝຸດເພື່ອປັບຕຳແໜ່ງ
      </div>
    </div>
  );
};
