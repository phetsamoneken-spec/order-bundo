import React, { useState, useRef } from 'react';
import { Product, ProductCategory, StoreProfile } from '../../types/pos';
import { formatKip, vibrateSoft, compressImage } from '../../utils/formatters';
import { downloadStandaloneHtml, getStandaloneHtml } from '../../utils/exportSingleFile';

interface CatalogTabProps {
  products: Product[];
  profile?: StoreProfile;
  onAddProduct: (prod: Product) => void;
  onDeleteProduct: (id: string) => void;
  onResetProducts: () => void;
  onOpenStoreSettings?: () => void;
  onShowToast: (msg: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
}

export const CatalogTab: React.FC<CatalogTabProps> = ({
  products,
  profile,
  onAddProduct,
  onDeleteProduct,
  onResetProducts,
  onOpenStoreSettings,
  onShowToast,
}) => {
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [name, setName] = useState<string>('');
  const [nameEn, setNameEn] = useState<string>('');
  const [sub, setSub] = useState<string>('');
  const [category, setCategory] = useState<ProductCategory>('drinks');
  const [price, setPrice] = useState<string>('25000');
  const [badgeText, setBadgeText] = useState<string>('');
  const [badgeType, setBadgeType] = useState<Product['badgeType']>('bestseller');
  const [imageUrl, setImageUrl] = useState<string>('');
  const [isCompressing, setIsCompressing] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressing(true);
      const dataUrl = await compressImage(file, 400, 0.75);
      setImageUrl(dataUrl);
      onShowToast('📸 ອັບໂຫຼດຮູບພາບສິນຄ້າສຳເລັດ', 'success');
    } catch {
      onShowToast('ບໍ່ສາມາດໂຫຼດຮູບພາບໄດ້', 'error');
    } finally {
      setIsCompressing(false);
    }
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      onShowToast('ກະລຸນາປ້ອນຊື່ສິນຄ້າ', 'warning');
      return;
    }

    const numPrice = parseInt(price, 10);
    if (isNaN(numPrice) || numPrice <= 0) {
      onShowToast('ກະລຸນາປ້ອນລາຄາທີ່ຖືກຕ້ອງ', 'warning');
      return;
    }

    // Default fallback image if none provided
    const fallbackImages = {
      drinks: 'https://images.unsplash.com/photo-1517256064527-09c73fc73e38?w=500&auto=format&fit=crop&q=60',
      food: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&auto=format&fit=crop&q=60',
      desserts: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?w=500&auto=format&fit=crop&q=60',
    };

    const newProd: Product = {
      id: `item-${Date.now()}`,
      name: name.trim(),
      nameEn: nameEn.trim() || name.trim(),
      sub: sub.trim() || 'ລາຍການໃໝ່',
      category,
      price: numPrice,
      image: imageUrl.trim() || fallbackImages[category],
      badgeText: badgeText.trim() || undefined,
      badgeType: badgeText.trim() ? badgeType : undefined,
    };

    onAddProduct(newProd);
    onShowToast(`✨ ເພີ່ມສິນຄ້າ "${newProd.name}" ສຳເລັດແລ້ວ!`, 'success');

    // Reset Form
    setName('');
    setNameEn('');
    setSub('');
    setPrice('25000');
    setBadgeText('');
    setImageUrl('');
    setShowAddModal(false);
  };

  return (
    <div className="flex flex-col w-full pb-32 max-w-lg mx-auto px-4 pt-2">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="font-display font-bold text-[22px] text-[#006c49]">
            ຈັດການລາຍການສິນຄ້າ
          </h1>
          <p className="text-[13px] text-[#3c4a42]">
            ມີທັງໝົດ {products.length} ລາຍການໃນເມນູ
          </p>
        </div>

        <button
          onClick={() => {
            vibrateSoft();
            setShowAddModal(true);
          }}
          className="flex items-center gap-1.5 bg-[#006c49] hover:bg-[#005236] text-white px-3.5 py-2 rounded-xl text-[13px] font-bold shadow-md active:scale-95 transition-all"
        >
          <span className="material-symbols-outlined text-[18px]">add_circle</span>
          <span>ເພີ່ມສິນຄ້າ</span>
        </button>
      </div>

      {/* Store Name & Logo Management Card */}
      {profile && onOpenStoreSettings && (
        <div className="mb-4 bg-white rounded-3xl p-4 shadow-sm border border-emerald-900/10 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            {profile.logoUrl ? (
              <img
                src={profile.logoUrl}
                alt={profile.name}
                className="w-12 h-12 rounded-2xl object-cover shadow-xs border border-emerald-900/10 bg-[#faf8ff] shrink-0"
              />
            ) : (
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#006c49] to-[#10b981] flex items-center justify-center text-white shrink-0 shadow-xs">
                <span className="material-symbols-outlined text-[26px]">
                  {profile.logoIcon || 'point_of_sale'}
                </span>
              </div>
            )}
            <div className="min-w-0">
              <span className="text-[11px] font-bold text-gray-400 block uppercase">
                ຊື່ຮ້ານ ແລະ ໂລໂກ້ປັດຈຸບັນ
              </span>
              <h3 className="font-display font-bold text-[16px] text-[#006c49] truncate">
                {profile.name}
              </h3>
              <p className="text-[12px] text-gray-500 truncate">
                {profile.phone || 'ຍັງບໍ່ມີເບີໂທ'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              vibrateSoft();
              onOpenStoreSettings();
            }}
            className="py-2 px-3.5 bg-[#ecfdf5] hover:bg-emerald-100 text-[#006c49] font-bold text-[12px] rounded-xl flex items-center gap-1.5 shrink-0 border border-[#a7f3d0] active:scale-95 transition-all"
          >
            <span className="material-symbols-outlined text-[16px]">edit</span>
            <span>ແກ້ໄຂ</span>
          </button>
        </div>
      )}

      {/* Standalone Single File index.html Card */}
      <div className="mb-4 bg-gradient-to-br from-emerald-800 via-emerald-700 to-teal-800 text-white rounded-3xl p-4 shadow-lg border border-emerald-500/30">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/15 backdrop-blur-md flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[24px] text-white">html</span>
            </div>
            <div>
              <h3 className="font-display font-bold text-[15px] leading-tight">
                ໄຟລ໌ດຽວ Standalone index.html
              </h3>
              <p className="text-[12px] text-emerald-100/90 mt-0.5">
                ລວມລະບົບ POS ທັງໝົດເປັນໄຟລ໌ດຽວ ເປີດໃຊ້ງານໄດ້ທັນທີ
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-white/10">
          <button
            onClick={() => {
              vibrateSoft(20);
              downloadStandaloneHtml();
              onShowToast('📥 ກຳລັງດາວໂຫລດ index.html ແລ້ວ!', 'success');
            }}
            className="py-2.5 px-3 bg-white text-[#006c49] rounded-xl text-[12px] font-bold flex items-center justify-center gap-1.5 shadow-sm hover:bg-emerald-50 active:scale-95 transition-all"
          >
            <span className="material-symbols-outlined text-[18px]">download</span>
            <span>ດາວໂຫລດ index.html</span>
          </button>

          <button
            onClick={async () => {
              vibrateSoft(20);
              try {
                const code = await getStandaloneHtml();
                await navigator.clipboard.writeText(code);
                onShowToast('📋 ສຳເນົາ Code index.html ທັງໝົດແລ້ວ!', 'success');
              } catch {
                onShowToast('ບໍ່ສາມາດສຳເນົາ Code ໄດ້', 'error');
              }
            }}
            className="py-2.5 px-3 bg-emerald-900/60 hover:bg-emerald-900/80 text-white border border-emerald-400/30 rounded-xl text-[12px] font-bold flex items-center justify-center gap-1.5 active:scale-95 transition-all"
          >
            <span className="material-symbols-outlined text-[18px]">content_copy</span>
            <span>ສຳເນົາ Code</span>
          </button>
        </div>
      </div>

      {/* Product List */}
      <div className="flex flex-col gap-2.5">
        {products.map((prod) => (
          <div
            key={prod.id}
            className="bg-white rounded-2xl p-3 shadow-xs border border-gray-100 flex items-center justify-between gap-3"
          >
            <div className="flex items-center gap-3 min-w-0">
              <img
                src={prod.image}
                alt={prod.name}
                className="w-14 h-14 rounded-xl object-cover bg-[#ecfdf5] shrink-0"
              />
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <h4 className="font-display font-bold text-[15px] text-[#131b2e] truncate">
                    {prod.name}
                  </h4>
                  {prod.badgeText && (
                    <span className="bg-[#ecfdf5] text-[#006c49] font-bold text-[10px] px-1.5 py-0.5 rounded-md">
                      {prod.badgeText}
                    </span>
                  )}
                </div>
                <p className="text-[12px] text-gray-500 truncate">
                  {prod.nameEn} • {prod.sub}
                </p>
                <p className="text-[13px] font-display font-black text-[#006c49] mt-0.5">
                  {formatKip(prod.price)} ກີບ
                </p>
              </div>
            </div>

            <button
              onClick={() => {
                if (window.confirm(`ຕ້ອງການລຶບສິນຄ້າ "${prod.name}" ອອກຈາກເມນູແທ້ຫຼືບໍ່?`)) {
                  vibrateSoft();
                  onDeleteProduct(prod.id);
                  onShowToast(`ລຶບ "${prod.name}" ແລ້ວ`, 'info');
                }
              }}
              className="w-9 h-9 rounded-xl hover:bg-red-50 text-gray-400 hover:text-red-600 flex items-center justify-center transition-colors shrink-0"
              title="ລຶບສິນຄ້າ"
            >
              <span className="material-symbols-outlined text-[18px]">delete</span>
            </button>
          </div>
        ))}
      </div>

      {/* Reset to Default Button */}
      <div className="pt-6 text-center">
        <button
          onClick={() => {
            if (window.confirm('ຕ້ອງການຣີເຊັດເມນູກັບຄືນສູ່ຄ່າເລີ່ມຕົ້ນ 6 ລາຍການແທ້ຫຼືບໍ່?')) {
              vibrateSoft();
              onResetProducts();
              onShowToast('ຣີເຊັດເມນູສິນຄ້າກັບຄືນຄ່າເລີ່ມຕົ້ນແລ້ວ', 'success');
            }
          }}
          className="text-[12px] text-gray-400 hover:text-[#006c49] font-bold underline transition-colors"
        >
          ຣີເຊັດເມນູກັບຄືນຄ່າເລີ່ມຕົ້ນ (Reset to Defaults)
        </button>
      </div>

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl border border-emerald-900/10 flex flex-col gap-4 max-h-[90vh] overflow-y-auto no-scrollbar">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-lg text-[#006c49]">
                ເພີ່ມສິນຄ້າໃໝ່
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-400 hover:text-gray-600 p-1"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="flex flex-col gap-3">
              {/* Product Name */}
              <div>
                <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
                  ຊື່ສິນຄ້າ (ພາສາລາວ) *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="ເຊັ່ນ: ຊາຂຽວມັດຊະເຢັນ"
                  className="w-full px-3 py-2 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
                />
              </div>

              {/* English & Sub */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
                    ຊື່ພາສາອັງກິດ
                  </label>
                  <input
                    type="text"
                    value={nameEn}
                    onChange={(e) => setNameEn(e.target.value)}
                    placeholder="Matcha Latte"
                    className="w-full px-3 py-2 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
                  />
                </div>
                <div>
                  <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
                    ຄຳອະທິບາຍສັ້ນ
                  </label>
                  <input
                    type="text"
                    value={sub}
                    onChange={(e) => setSub(e.target.value)}
                    placeholder="ຫອມລະມຸນ"
                    className="w-full px-3 py-2 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
                  />
                </div>
              </div>

              {/* Category & Price */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
                    ໝວດໝູ່
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ProductCategory)}
                    className="w-full px-3 py-2 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
                  >
                    <option value="drinks">ເຄື່ອງດື່ມ</option>
                    <option value="food">ອາຫານ</option>
                    <option value="desserts">ຂອງຫວານ</option>
                  </select>
                </div>

                <div>
                  <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
                    ລາຄາ (ກີບ) *
                  </label>
                  <input
                    type="number"
                    step="1000"
                    required
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    className="w-full px-3 py-2 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] font-display font-bold text-[#006c49] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
                  />
                </div>
              </div>

              {/* Badge */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
                    ປ້າຍກຳກັບ (Badge)
                  </label>
                  <input
                    type="text"
                    value={badgeText}
                    onChange={(e) => setBadgeText(e.target.value)}
                    placeholder="ເຊັ່ນ: ຂາຍດີ, ແນະນຳ..."
                    className="w-full px-3 py-2 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
                  />
                </div>

                <div>
                  <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
                    ສີປ້າຍ
                  </label>
                  <select
                    value={badgeType}
                    onChange={(e) => setBadgeType(e.target.value as any)}
                    className="w-full px-3 py-2 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
                  >
                    <option value="bestseller">ດາວ ຂາຍດີ (Star)</option>
                    <option value="recommended">ແນະນຳ (Recommended)</option>
                    <option value="spicy">ເຜັດແຊບ (Spicy Red)</option>
                    <option value="sweet">ຫວານ (Subtle Gray)</option>
                  </select>
                </div>
              </div>

              {/* Photo Input */}
              <div>
                <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
                  ຮູບພາບສິນຄ້າ
                </label>
                <div className="flex gap-2 items-center">
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="image/*"
                    onChange={handleImageFile}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isCompressing}
                    className="flex-1 py-2 px-3 bg-[#faf8ff] hover:bg-[#ecfdf5] border border-dashed border-[#006c49]/40 rounded-xl text-[12px] font-bold text-[#006c49] flex items-center justify-center gap-1.5"
                  >
                    <span className="material-symbols-outlined text-[18px]">upload</span>
                    <span>{imageUrl ? 'ປ່ຽນຮູບພາບ' : 'ອັບໂຫຼດຮູບ'}</span>
                  </button>

                  {imageUrl && (
                    <img
                      src={imageUrl}
                      alt="Preview"
                      className="w-10 h-10 rounded-xl object-cover border border-emerald-800/10 shrink-0"
                    />
                  )}
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-[13px] transition-colors"
                >
                  ຍົກເລີກ
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-[#006c49] hover:bg-[#005236] text-white font-bold rounded-xl text-[13px] shadow-sm transition-all active:scale-95"
                >
                  ບັນທຶກສິນຄ້າ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
