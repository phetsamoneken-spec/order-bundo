import React, { useMemo } from 'react';
import { Order, Product } from '../../types/pos';
import { formatKip } from '../../utils/formatters';

interface DashboardTabProps {
  orders: Order[];
  products: Product[];
}

export const DashboardTab: React.FC<DashboardTabProps> = ({ orders, products }) => {
  // KPI Metrics Calculation
  const stats = useMemo(() => {
    const today = new Date().toISOString().slice(0, 10);

    let todaySales = 0;
    let totalRevenue = 0;
    const totalOrders = orders.length;

    // Track category breakdown
    const categoryTotals: Record<string, number> = {
      drinks: 0,
      food: 0,
      desserts: 0,
    };

    // Track item sales
    const itemSales: Record<string, { name: string; qty: number; revenue: number }> = {};

    orders.forEach((order) => {
      totalRevenue += order.total;
      const orderDate = order.createdAt.slice(0, 10);
      if (orderDate === today) {
        todaySales += order.total;
      }

      order.items.forEach((it) => {
        if (categoryTotals[it.category] !== undefined) {
          categoryTotals[it.category] += it.quantity * it.unitPrice;
        } else {
          categoryTotals['food'] = (categoryTotals['food'] || 0) + it.quantity * it.unitPrice;
        }

        if (!itemSales[it.productId]) {
          itemSales[it.productId] = { name: it.productName, qty: 0, revenue: 0 };
        }
        itemSales[it.productId].qty += it.quantity;
        itemSales[it.productId].revenue += it.quantity * it.unitPrice;
      });
    });

    const averageOrder = totalOrders > 0 ? Math.round(totalRevenue / totalOrders) : 0;

    // Top selling items sorted by quantity
    const topItems = Object.values(itemSales)
      .sort((a, b) => b.qty - a.qty)
      .slice(0, 5);

    return {
      todaySales,
      totalRevenue,
      totalOrders,
      averageOrder,
      categoryTotals,
      topItems,
    };
  }, [orders]);

  // Last 7 days data points for chart
  const weeklyData = useMemo(() => {
    const days: { label: string; date: string; amount: number }[] = [];
    const dayNames = ['ອາທິດ', 'ຈັນ', 'ອັງຄານ', 'ພຸດ', 'ພະຫັດ', 'ສຸກ', 'ເສົາ'];

    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().slice(0, 10);
      const dayLabel = dayNames[d.getDay()];

      let dayTotal = 0;
      orders.forEach((ord) => {
        if (ord.createdAt.slice(0, 10) === dateStr) {
          dayTotal += ord.total;
        }
      });

      days.push({
        label: dayLabel,
        date: dateStr,
        amount: dayTotal,
      });
    }

    const maxAmount = Math.max(...days.map((d) => d.amount), 50000);
    return { days, maxAmount };
  }, [orders]);

  // Total for categories
  const totalCatSum =
    stats.categoryTotals.drinks + stats.categoryTotals.food + stats.categoryTotals.desserts || 1;

  const drinkPct = Math.round((stats.categoryTotals.drinks / totalCatSum) * 100);
  const foodPct = Math.round((stats.categoryTotals.food / totalCatSum) * 100);
  const dessertPct = 100 - drinkPct - foodPct;

  return (
    <div className="flex flex-col w-full pb-32 max-w-lg mx-auto px-4 pt-2">
      {/* Title */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="font-display font-bold text-[22px] text-[#006c49]">
            ສະຫຼຸບຍອດຂາຍ &amp; ລາຍຮັບ
          </h1>
          <p className="text-[13px] text-[#3c4a42]">ລາຍງານຜົນການຂາຍແບບ Real-time</p>
        </div>
        <div className="bg-[#ecfdf5] text-[#006c49] font-display font-bold text-[12px] px-3 py-1 rounded-full border border-[#a7f3d0]/60 flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-[#10b981]"></span>
          <span>ອັບເດດສົດ</span>
        </div>
      </div>

      {/* 4 KPI Cards Grid */}
      <div className="grid grid-cols-2 gap-3 mb-5">
        {/* Card 1: Today's Sales */}
        <div className="bg-white rounded-2xl p-3.5 shadow-sm border border-emerald-900/5 relative overflow-hidden">
          <div className="w-8 h-8 rounded-xl bg-[#ecfdf5] flex items-center justify-center text-[#006c49] mb-2">
            <span className="material-symbols-outlined text-[18px]">today</span>
          </div>
          <p className="text-[11px] font-semibold text-[#3c4a42]">ຍອດຂາຍມື້ນີ້</p>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="font-display font-black text-[18px] text-[#006c49]">
              {formatKip(stats.todaySales)}
            </span>
            <span className="text-[10px] text-gray-500 font-bold">ກີບ</span>
          </div>
        </div>

        {/* Card 2: Total Revenue */}
        <div className="bg-white rounded-2xl p-3.5 shadow-sm border border-emerald-900/5 relative overflow-hidden">
          <div className="w-8 h-8 rounded-xl bg-amber-50 flex items-center justify-center text-[#f59e0b] mb-2">
            <span className="material-symbols-outlined text-[18px]">payments</span>
          </div>
          <p className="text-[11px] font-semibold text-[#3c4a42]">ລາຍຮັບລວມທັງໝົດ</p>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="font-display font-black text-[18px] text-[#131b2e]">
              {formatKip(stats.totalRevenue)}
            </span>
            <span className="text-[10px] text-gray-500 font-bold">ກີບ</span>
          </div>
        </div>

        {/* Card 3: Total Orders */}
        <div className="bg-white rounded-2xl p-3.5 shadow-sm border border-emerald-900/5 relative overflow-hidden">
          <div className="w-8 h-8 rounded-xl bg-emerald-50 flex items-center justify-center text-[#10b981] mb-2">
            <span className="material-symbols-outlined text-[18px]">receipt</span>
          </div>
          <p className="text-[11px] font-semibold text-[#3c4a42]">ຈຳນວນອໍເດີ້</p>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="font-display font-black text-[20px] text-[#131b2e]">
              {stats.totalOrders}
            </span>
            <span className="text-[10px] text-gray-500 font-bold">ບິນ</span>
          </div>
        </div>

        {/* Card 4: Average Order */}
        <div className="bg-white rounded-2xl p-3.5 shadow-sm border border-emerald-900/5 relative overflow-hidden">
          <div className="w-8 h-8 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 mb-2">
            <span className="material-symbols-outlined text-[18px]">analytics</span>
          </div>
          <p className="text-[11px] font-semibold text-[#3c4a42]">ຄ່າສະເລ່ຍຕໍ່ບິນ</p>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="font-display font-black text-[18px] text-[#006c49]">
              {formatKip(stats.averageOrder)}
            </span>
            <span className="text-[10px] text-gray-500 font-bold">ກີບ</span>
          </div>
        </div>
      </div>

      {/* 7-Day Revenue Trend Chart */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col gap-3 mb-5">
        <div className="flex items-center justify-between">
          <h3 className="font-display font-bold text-[15px] text-[#131b2e] flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[18px] text-[#006c49]">trending_up</span>
            <span>ແນວໂນ້ມຍອດຂາຍ 7 ມື້ຜ່ານມາ</span>
          </h3>
          <span className="text-[11px] text-gray-400 font-medium">ຫົວໜ່ວຍ: ກີບ</span>
        </div>

        {/* SVG Sales Trend Chart */}
        <div className="w-full pt-4 pb-1">
          <div className="flex items-end justify-between h-36 gap-2 px-1">
            {weeklyData.days.map((day, idx) => {
              const heightPct = Math.max(8, Math.round((day.amount / weeklyData.maxAmount) * 100));
              const isToday = idx === weeklyData.days.length - 1;

              return (
                <div key={day.date} className="flex-1 flex flex-col items-center gap-1.5 h-full justify-end group">
                  {/* Tooltip on hover */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity text-[10px] font-display font-bold text-[#006c49] bg-[#ecfdf5] px-1 py-0.5 rounded shadow-xs mb-0.5 whitespace-nowrap pointer-events-none">
                    {formatKip(day.amount)}
                  </div>

                  {/* Bar */}
                  <div className="w-full max-w-[28px] bg-gray-100 rounded-t-lg overflow-hidden flex flex-col justify-end" style={{ height: '100px' }}>
                    <div
                      style={{ height: `${heightPct}%` }}
                      className={`w-full rounded-t-lg transition-all duration-500 ${
                        isToday
                          ? 'bg-gradient-to-t from-[#006c49] to-[#10b981]'
                          : 'bg-gradient-to-t from-emerald-600 to-emerald-400'
                      }`}
                    />
                  </div>

                  {/* Day label */}
                  <span className={`text-[11px] font-semibold ${isToday ? 'text-[#006c49] font-bold' : 'text-gray-500'}`}>
                    {day.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Category Breakdown */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col gap-3 mb-5">
        <h3 className="font-display font-bold text-[15px] text-[#131b2e] flex items-center gap-1.5">
          <span className="material-symbols-outlined text-[18px] text-[#006c49]">pie_chart</span>
          <span>ສັດສ່ວນຍອດຂາຍຕາມໝວດໝູ່</span>
        </h3>

        {/* Stacked Progress Bar */}
        <div className="w-full h-3 rounded-full overflow-hidden flex bg-gray-100 shadow-inner">
          <div style={{ width: `${drinkPct}%` }} className="bg-[#006c49] h-full transition-all" title={`Drinks ${drinkPct}%`} />
          <div style={{ width: `${foodPct}%` }} className="bg-[#10b981] h-full transition-all" title={`Food ${foodPct}%`} />
          <div style={{ width: `${dessertPct}%` }} className="bg-[#f59e0b] h-full transition-all" title={`Desserts ${dessertPct}%`} />
        </div>

        {/* Legend */}
        <div className="grid grid-cols-3 gap-2 pt-1 text-center">
          <div className="flex flex-col items-center bg-[#faf8ff] p-2 rounded-xl border border-gray-100">
            <div className="flex items-center gap-1 text-[11px] font-bold text-[#006c49]">
              <span className="w-2.5 h-2.5 rounded-full bg-[#006c49]"></span>
              <span>ເຄື່ອງດື່ມ</span>
            </div>
            <span className="font-display font-black text-[14px] text-[#131b2e] mt-1">{drinkPct}%</span>
            <span className="text-[10px] text-gray-500">{formatKip(stats.categoryTotals.drinks)} ກີບ</span>
          </div>

          <div className="flex flex-col items-center bg-[#faf8ff] p-2 rounded-xl border border-gray-100">
            <div className="flex items-center gap-1 text-[11px] font-bold text-[#10b981]">
              <span className="w-2.5 h-2.5 rounded-full bg-[#10b981]"></span>
              <span>ອາຫານ</span>
            </div>
            <span className="font-display font-black text-[14px] text-[#131b2e] mt-1">{foodPct}%</span>
            <span className="text-[10px] text-gray-500">{formatKip(stats.categoryTotals.food)} ກີບ</span>
          </div>

          <div className="flex flex-col items-center bg-[#faf8ff] p-2 rounded-xl border border-gray-100">
            <div className="flex items-center gap-1 text-[11px] font-bold text-[#f59e0b]">
              <span className="w-2.5 h-2.5 rounded-full bg-[#f59e0b]"></span>
              <span>ຂອງຫວານ</span>
            </div>
            <span className="font-display font-black text-[14px] text-[#131b2e] mt-1">{dessertPct}%</span>
            <span className="text-[10px] text-gray-500">{formatKip(stats.categoryTotals.desserts)} ກີບ</span>
          </div>
        </div>
      </div>

      {/* Top Selling Items Leaderboard */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col gap-3">
        <h3 className="font-display font-bold text-[15px] text-[#131b2e] flex items-center gap-1.5">
          <span className="material-symbols-outlined text-[18px] text-[#f59e0b]">military_tech</span>
          <span>5 ລາຍການຂາຍດີທີ່ສຸດ (Top Sellers)</span>
        </h3>

        {stats.topItems.length === 0 ? (
          <p className="text-center text-xs text-gray-400 py-4">ຍັງບໍ່ມີຂໍ້ມູນການຂາຍ</p>
        ) : (
          <div className="flex flex-col divide-y divide-gray-100">
            {stats.topItems.map((item, index) => (
              <div key={item.name} className="py-2.5 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <span
                    className={`w-6 h-6 rounded-full flex items-center justify-center font-display font-black text-[11px] shrink-0 ${
                      index === 0
                        ? 'bg-[#f59e0b] text-white'
                        : index === 1
                        ? 'bg-gray-300 text-gray-800'
                        : index === 2
                        ? 'bg-amber-700/60 text-white'
                        : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {index + 1}
                  </span>
                  <span className="font-bold text-[14px] text-[#131b2e] truncate">
                    {item.name}
                  </span>
                </div>

                <div className="text-right shrink-0">
                  <div className="font-display font-bold text-[13px] text-[#006c49]">
                    {formatKip(item.revenue)} ກີບ
                  </div>
                  <div className="text-[11px] text-gray-400">
                    ຂາຍແລ້ວ {item.qty} ລາຍການ
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
