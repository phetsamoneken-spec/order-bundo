import React from 'react';
import { ActiveTab, StoreProfile } from '../types/pos';

interface HeaderProps {
  activeTab: ActiveTab;
  profile: StoreProfile;
  onOpenGpsModal: () => void;
  onQuickSync: () => void;
  onExportHtml?: () => void;
  onEditStore?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  profile,
  onOpenGpsModal,
  onQuickSync,
  onExportHtml,
  onEditStore,
}) => {
  const getTabSubtitle = () => {
    switch (activeTab) {
      case 'pos-menu':
        return 'Pos Menu';
      case 'cart-and-whatsapp':
        return 'Cart & WhatsApp';
      case 'sales-dashboard':
        return 'Sales Dashboard';
      case 'order-history':
        return 'Order History';
      case 'catalog-settings':
        return 'Catalog Settings';
    }
  };

  return (
    <header className="fixed top-0 inset-x-0 z-50 bg-[#faf8ff]/85 backdrop-blur-xl shadow-[0_1px_12px_rgba(0,108,73,0.06)] border-b border-emerald-900/5">
      <div className="h-16 max-w-lg mx-auto px-4 flex items-center justify-between gap-2">
        {/* Left Branding & GPS status */}
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          {/* Store Logo (Photo or Icon Box) */}
          <button
            onClick={onEditStore}
            className="relative group shrink-0 active:scale-95 transition-transform"
            title="ກົດເພື່ອປ່ຽນໂລໂກ້ ຫຼື ຊື່ຮ້ານ"
          >
            {profile.logoUrl ? (
              <img
                src={profile.logoUrl}
                alt={profile.name}
                className="w-10 h-10 rounded-xl object-cover shadow-sm border border-emerald-900/10 bg-white"
              />
            ) : (
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#006c49] to-[#10b981] flex items-center justify-center text-white shrink-0 shadow-sm shadow-emerald-900/20">
                <span className="material-symbols-outlined text-[24px]">
                  {profile.logoIcon || 'point_of_sale'}
                </span>
              </div>
            )}
            <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-white rounded-full shadow-xs flex items-center justify-center text-[#006c49] border border-emerald-100">
              <span className="material-symbols-outlined text-[10px]">edit</span>
            </span>
          </button>

          <div className="flex flex-col min-w-0">
            <button
              onClick={onEditStore}
              className="flex items-center gap-1 group text-left max-w-full"
              title="ກົດເພື່ອແກ້ໄຂຊື່ຮ້ານ"
            >
              <span className="font-display font-bold text-[17px] text-[#006c49] truncate leading-tight tracking-tight group-hover:underline">
                {profile.name}
              </span>
              <span className="material-symbols-outlined text-[14px] text-[#006c49]/70 group-hover:text-[#006c49] shrink-0">
                edit
              </span>
            </button>
            <button
              onClick={onOpenGpsModal}
              className="flex items-center gap-1 mt-0.5 text-left group transition-opacity active:opacity-75"
              title="ກົດເພື່ອຕັ້ງຄ່າ GPS"
            >
              <span className="w-2 h-2 rounded-full bg-[#10b981] animate-pulse shrink-0"></span>
              <span className="text-[12px] text-[#3c4a42] flex items-center gap-0.5 truncate font-medium">
                <span className="material-symbols-outlined text-[13px] text-[#006c49]">location_on</span>
                GPS ເປີດໃຊ້ງານ • <span className="text-[#006c49] font-bold group-hover:underline">{getTabSubtitle()}</span>
              </span>
            </button>
          </div>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center gap-1.5 shrink-0">
          {onExportHtml && (
            <button
              onClick={onExportHtml}
              className="w-9 h-9 rounded-xl bg-emerald-50 text-[#006c49] flex items-center justify-center hover:bg-emerald-100 transition-colors active:scale-95 border border-emerald-600/20"
              aria-label="Download index.html"
              title="ດາວໂຫລດ index.html (ໄຟລ໌ດຽວ Standalone)"
            >
              <span className="material-symbols-outlined text-[19px]">download</span>
            </button>
          )}
          <button
            onClick={onQuickSync}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-[#3c4a42] hover:text-[#006c49] hover:bg-[#ecfdf5] transition-colors active:scale-95"
            aria-label="Cloud sync"
            title="ຊິງຄ໌ຂໍ້ມູນອອບໄລນ໌"
          >
            <span className="material-symbols-outlined text-[20px]">wifi_tethering</span>
          </button>
          <div
            className="w-8 h-8 rounded-full bg-[#006c49] flex items-center justify-center shrink-0 shadow-sm cursor-pointer hover:bg-[#005236] transition-colors active:scale-95"
            title="ຜູ້ໃຊ້ງານ: Cashier POS"
          >
            <span className="material-symbols-outlined text-white text-[18px]">person</span>
          </div>
        </div>
      </div>
    </header>
  );
};
