import React, { useState, useRef } from 'react';
import { StoreProfile } from '../types/pos';
import { compressImage, vibrateSoft } from '../utils/formatters';

interface StoreSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: StoreProfile;
  onUpdateProfile: (updated: Partial<StoreProfile>) => void;
  onShowToast: (msg: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
}

const PRESET_ICONS = [
  { icon: 'point_of_sale', label: 'POS' },
  { icon: 'local_cafe', label: 'ກາເຟ' },
  { icon: 'restaurant', label: 'ອາຫານ' },
  { icon: 'bakery_dining', label: 'ຂອງຫວານ' },
  { icon: 'lunch_dining', label: 'ເບີເກີ້' },
  { icon: 'local_bar', label: 'ບາ/ເຄື່ອງດື່ມ' },
  { icon: 'storefront', label: 'ໜ້າຮ້ານ' },
  { icon: 'shopping_basket', label: 'ມາດ' },
];

export const StoreSettingsModal: React.FC<StoreSettingsModalProps> = ({
  isOpen,
  onClose,
  profile,
  onUpdateProfile,
  onShowToast,
}) => {
  const [storeName, setStoreName] = useState(profile.name);
  const [ownerName, setOwnerName] = useState(profile.ownerName || profile.cashierName || '');
  const [phone, setPhone] = useState(profile.phone || '');
  const [logoUrl, setLogoUrl] = useState<string | null>(profile.logoUrl || null);
  const [logoIcon, setLogoIcon] = useState<string>(profile.logoIcon || 'point_of_sale');
  const [isUploading, setIsUploading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleUploadLogo = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploading(true);
      const compressed = await compressImage(file, 300, 0.85);
      setLogoUrl(compressed);
      onShowToast('📸 ອັບໂຫຼດຮູບໂລໂກ້ຮຽບຮ້ອຍແລ້ວ', 'success');
    } catch {
      onShowToast('ເກີດຂໍ້ຜິດພາດໃນການອັບໂຫຼດຮູບໂລໂກ້', 'error');
    } finally {
      setIsUploading(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!storeName.trim()) {
      onShowToast('ກະລຸນາປ້ອນຊື່ຮ້ານ', 'warning');
      return;
    }

    vibrateSoft(30);
    onUpdateProfile({
      name: storeName.trim(),
      ownerName: ownerName.trim(),
      cashierName: ownerName.trim(),
      phone: phone.trim(),
      logoUrl,
      logoIcon,
    });

    onShowToast('✨ ບັນທຶກຊື່ຮ້ານ ແລະ ໂລໂກ້ສຳເລັດແລ້ວ!', 'success');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl border border-emerald-900/10 flex flex-col gap-4 max-h-[90vh] overflow-y-auto no-scrollbar">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-[#006c49]">
            <span className="material-symbols-outlined text-[24px]">storefront</span>
            <h3 className="font-display font-bold text-lg leading-tight">
              ແກ້ໄຂຊື່ຮ້ານ &amp; ໂລໂກ້
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full hover:bg-gray-100 text-gray-400 hover:text-gray-700 flex items-center justify-center transition-colors"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Live Preview Box */}
        <div className="bg-[#faf8ff] p-3.5 rounded-2xl border border-[#dae2fd]/60 flex items-center gap-3">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt="Logo Preview"
              className="w-12 h-12 rounded-xl object-cover shadow-sm border border-emerald-900/10 bg-white shrink-0"
            />
          ) : (
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#006c49] to-[#10b981] flex items-center justify-center text-white shrink-0 shadow-sm">
              <span className="material-symbols-outlined text-[26px]">
                {logoIcon || 'point_of_sale'}
              </span>
            </div>
          )}

          <div className="min-w-0 flex-1">
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block">
              ຕົວຢ່າງການສະແດງຜົນ
            </span>
            <h4 className="font-display font-bold text-[16px] text-[#006c49] truncate">
              {storeName.trim() || 'ຊື່ຮ້ານຂອງທ່ານ'}
            </h4>
            <p className="text-[11px] text-[#3c4a42] truncate">
              {phone.trim() || 'ເບີໂທຕິດຕໍ່'}
            </p>
          </div>
        </div>

        <form onSubmit={handleSave} className="flex flex-col gap-3.5">
          {/* Logo Section */}
          <div className="flex flex-col gap-2">
            <label className="text-[12px] font-bold text-[#3c4a42] flex items-center justify-between">
              <span>ໂລໂກ້ຮ້ານ (Logo)</span>
              {logoUrl && (
                <button
                  type="button"
                  onClick={() => {
                    vibrateSoft();
                    setLogoUrl(null);
                  }}
                  className="text-[#ba1a1a] hover:underline text-[11px]"
                >
                  ໃຊ້ໄອຄອນເລີ່ມຕົ້ນ
                </button>
              )}
            </label>

            {/* Upload Button */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              onChange={handleUploadLogo}
              className="hidden"
            />

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="flex-1 py-2.5 px-3 bg-[#ecfdf5] hover:bg-emerald-100 text-[#006c49] rounded-xl text-[12px] font-bold flex items-center justify-center gap-1.5 border border-[#a7f3d0] transition-colors"
              >
                <span className="material-symbols-outlined text-[18px]">photo_camera</span>
                <span>{isUploading ? 'ກຳລັງອັບໂຫຼດ...' : logoUrl ? 'ປ່ຽນຮູບໂລໂກ້' : 'ອັບໂຫຼດຮູບໂລໂກ້'}</span>
              </button>
            </div>

            {/* Preset Icon Selector if no photo */}
            {!logoUrl && (
              <div className="flex flex-col gap-1.5 mt-1">
                <span className="text-[11px] text-gray-500 font-semibold">
                  ຫຼື ເລືອກໄອຄອນປະເພດຮ້ານ:
                </span>
                <div className="grid grid-cols-4 gap-1.5">
                  {PRESET_ICONS.map((item) => (
                    <button
                      key={item.icon}
                      type="button"
                      onClick={() => {
                        vibrateSoft(10);
                        setLogoIcon(item.icon);
                      }}
                      className={`p-2 rounded-xl flex flex-col items-center gap-1 text-[10px] font-bold transition-all ${
                        logoIcon === item.icon
                          ? 'bg-[#006c49] text-white shadow-sm'
                          : 'bg-gray-50 hover:bg-gray-100 text-gray-700 border border-gray-200'
                      }`}
                    >
                      <span className="material-symbols-outlined text-[18px]">
                        {item.icon}
                      </span>
                      <span className="truncate">{item.label}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Store Name Input */}
          <div>
            <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
              ຊື່ຮ້ານ (Store Name) *
            </label>
            <input
              type="text"
              required
              value={storeName}
              onChange={(e) => setStoreName(e.target.value)}
              placeholder="ເຊັ່ນ: ຮ້ານ ກາເຟ & ອາຫານ ລາວ POS"
              className="w-full px-3.5 py-2.5 bg-[#faf8ff] rounded-xl border border-gray-200 text-[14px] font-bold text-[#006c49] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
            />
          </div>

          {/* Owner/Cashier Name */}
          <div>
            <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
              ເຈົ້າຂອງຮ້ານ / ພະນັກງານຂາຍ
            </label>
            <input
              type="text"
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              placeholder="ເຊັ່ນ: ສົມສັກ ແກ້ວມະນີ"
              className="w-full px-3.5 py-2.5 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
            />
          </div>

          {/* Phone Number */}
          <div>
            <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
              ເບີໂທຕິດຕໍ່ຮ້ານ
            </label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="020 xxxx xxxx"
              className="w-full px-3.5 py-2.5 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] font-display text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
            />
          </div>

          {/* Google Drive Storage Location */}
          <div className="bg-[#faf8ff] rounded-xl p-3 border border-emerald-900/10 flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[12px] font-bold text-[#006c49] flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[17px]">cloud_upload</span>
                <span>ໂຟນເດີ Google Drive ບັນທຶກຮູບ</span>
              </span>
              <a
                href="https://drive.google.com/drive/folders/1JFlPMCT6FyANB_3XN7wFhaGIQK7NEU2x"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[11px] font-bold text-[#006c49] hover:underline flex items-center gap-0.5"
              >
                <span>ເປີດ Drive</span>
                <span className="material-symbols-outlined text-[12px]">open_in_new</span>
              </a>
            </div>
            <p className="text-[11px] text-gray-500 font-mono truncate bg-white px-2 py-1 rounded border border-gray-200 select-all">
              1JFlPMCT6FyANB_3XN7wFhaGIQK7NEU2x
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-[13px] transition-colors"
            >
              ຍົກເລີກ
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 bg-[#006c49] hover:bg-[#005236] text-white font-bold rounded-xl text-[13px] shadow-sm transition-all active:scale-95 flex items-center justify-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[18px]">check</span>
              <span>ບັນທຶກ</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
