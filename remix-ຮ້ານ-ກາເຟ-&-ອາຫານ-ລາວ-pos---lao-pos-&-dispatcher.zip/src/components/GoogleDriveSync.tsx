import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import {
  initAuth,
  googleSignIn,
  googleLogout,
  getAccessToken,
  setAccessTokenInMemory,
} from '../services/googleAuth';
import {
  DEFAULT_DRIVE_FOLDER_ID,
  uploadPhotoToDrive,
  listFolderFiles,
  DriveUploadResult,
} from '../services/driveService';

interface GoogleDriveSyncProps {
  currentPhotoUrl: string | null;
  storeName: string;
  onPhotoUploadedToDrive?: (driveLink: string) => void;
  onShowToast: (message: string, type?: 'success' | 'error' | 'info' | 'warning') => void;
}

export const GoogleDriveSync: React.FC<GoogleDriveSyncProps> = ({
  currentPhotoUrl,
  storeName,
  onPhotoUploadedToDrive,
  onShowToast,
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [lastUploaded, setLastUploaded] = useState<DriveUploadResult | null>(null);
  const [recentFiles, setRecentFiles] = useState<DriveUploadResult[]>([]);
  const [autoUpload, setAutoUpload] = useState<boolean>(() => {
    try {
      return localStorage.getItem('auto_drive_upload') === 'true';
    } catch {
      return false;
    }
  });

  const folderUrl = `https://drive.google.com/drive/folders/${DEFAULT_DRIVE_FOLDER_ID}`;

  // Initialize Auth state listener
  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, accessToken) => {
        setUser(currentUser);
        setToken(accessToken);
        fetchRecentFiles(accessToken);
      },
      () => {
        setUser(null);
        setToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const fetchRecentFiles = async (accessToken: string) => {
    const files = await listFolderFiles(accessToken, DEFAULT_DRIVE_FOLDER_ID);
    setRecentFiles(files);
  };

  const handleSignIn = async () => {
    setIsSigningIn(true);
    try {
      const res = await googleSignIn();
      setUser(res.user);
      setToken(res.accessToken);
      onShowToast(`ເຂົ້າສູ່ລະບົບ Google ແລ້ວ (${res.user.email || 'ສຳເລັດ'})`, 'success');
      await fetchRecentFiles(res.accessToken);
    } catch (err: any) {
      if (err.code !== 'auth/popup-closed-by-user') {
        onShowToast(`ບໍ່ສາມາດເຊື່ອມຕໍ່ Google ໄດ້: ${err.message || 'Error'}`, 'error');
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    await googleLogout();
    setUser(null);
    setToken(null);
    setRecentFiles([]);
    onShowToast('ອອກຈາກລະບົບ Google ແລ້ວ', 'info');
  };

  // Upload current photo to the user's specific Drive folder
  const handleUploadCurrentPhoto = async () => {
    if (!currentPhotoUrl) {
      onShowToast('ກະລຸນາຖ່າຍ ຫຼື ເລືອກຮູບໜ້າຮ້ານກ່ອນ', 'warning');
      return;
    }

    let activeToken = token;
    if (!activeToken) {
      // Prompt user to sign in first
      try {
        setIsSigningIn(true);
        const res = await googleSignIn();
        setUser(res.user);
        setToken(res.accessToken);
        activeToken = res.accessToken;
      } catch {
        setIsSigningIn(false);
        return;
      }
      setIsSigningIn(false);
    }

    setIsUploading(true);
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `${storeName.replace(/\s+/g, '_')}_storefront_${timestamp}.jpg`;

      const result = await uploadPhotoToDrive(
        activeToken,
        currentPhotoUrl,
        filename,
        DEFAULT_DRIVE_FOLDER_ID
      );

      setLastUploaded(result);
      if (result.webViewLink && onPhotoUploadedToDrive) {
        onPhotoUploadedToDrive(result.webViewLink);
      }

      onShowToast('✅ ບັນທຶກຮູບລົງ Google Drive ສຳເລັດແລ້ວ!', 'success');
      await fetchRecentFiles(activeToken);
    } catch (err: any) {
      console.error(err);
      onShowToast(`ອັບໂຫຼດລົງ Drive ບໍ່ສຳເລັດ: ${err.message}`, 'error');
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm border border-emerald-900/10 flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-[#ecfdf5] border border-emerald-200/80 flex items-center justify-center text-[#006c49]">
            <svg className="w-5 h-5" viewBox="0 0 87.3 78" xmlns="http://www.w3.org/2000/svg">
              <path d="m6.6 66.85 3.85 6.65c.8 1.4 1.95 2.5 3.3 3.3l13.75-23.8h-27.5c0 1.55.4 3.1 1.2 4.5z" fill="#0066da"/>
              <path d="m43.65 25-13.75-23.8c-1.35.8-2.5 1.9-3.3 3.3l-25.4 44c-.8 1.4-1.2 2.95-1.2 4.5h27.5z" fill="#00ac47"/>
              <path d="m73.55 76.8c1.35-.8 2.5-1.9 3.3-3.3l1.6-2.75 7.65-13.25c.8-1.4 1.2-2.95 1.2-4.5h-27.502l5.852 11.5z" fill="#ea4335"/>
              <path d="m43.65 25 13.75-23.8c-1.35-.8-2.9-1.2-4.5-1.2h-18.5c-1.6 0-3.15.45-4.5 1.2z" fill="#00832d"/>
              <path d="m59.8 53h-32.3l-13.75 23.8c1.35.8 2.9 1.2 4.5 1.2h50.8c1.6 0 3.15-.45 4.5-1.2z" fill="#2684fc"/>
              <path d="m73.4 26.5-12.7-22c-.8-1.4-1.95-2.5-3.3-3.3l-13.75 23.8 16.15 28h27.45c0-1.55-.4-3.1-1.2-4.5z" fill="#ffba00"/>
            </svg>
          </div>
          <div>
            <h4 className="font-display font-bold text-[14px] text-[#131b2e] flex items-center gap-1.5">
              <span>ບັນທຶກຮູບລົງ Google Drive</span>
              <span className="text-[10px] font-extrabold bg-[#ecfdf5] text-[#006c49] px-2 py-0.5 rounded-full border border-emerald-300/60">
                100% ຟຣີ
              </span>
            </h4>
            <p className="text-[11px] text-gray-500">
              ໂຟນເດີ: <span className="font-mono text-[#006c49] font-bold">1JFl...EU2x</span>
            </p>
          </div>
        </div>

        <a
          href={folderUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="text-[11px] font-bold text-[#006c49] hover:underline flex items-center gap-0.5 bg-[#ecfdf5] px-2 py-1 rounded-lg"
          title="ເປີດໂຟນເດີໃນ Google Drive"
        >
          <span>ເປີດ Drive</span>
          <span className="material-symbols-outlined text-[12px]">open_in_new</span>
        </a>
      </div>

      {/* Target Folder Details */}
      <div className="bg-[#faf8ff] rounded-xl p-2.5 border border-gray-100 flex items-center justify-between text-[11px]">
        <div className="flex items-center gap-1.5 text-gray-600 truncate mr-2">
          <span className="material-symbols-outlined text-[16px] text-amber-500 shrink-0">folder</span>
          <span className="font-mono text-[10.5px] truncate select-all">{DEFAULT_DRIVE_FOLDER_ID}</span>
        </div>
        <span className="text-[#006c49] font-bold shrink-0">ໂຟນເດີປາຍທາງ</span>
      </div>

      {/* Auth Status & Login Button */}
      {!user ? (
        <div className="flex flex-col gap-2 pt-1">
          <button
            type="button"
            onClick={handleSignIn}
            disabled={isSigningIn}
            className="w-full py-2.5 px-4 bg-white hover:bg-gray-50 border border-gray-300 text-gray-700 font-display font-semibold text-[13px] rounded-xl flex items-center justify-center gap-2.5 shadow-xs active:scale-98 transition-all disabled:opacity-50"
          >
            {isSigningIn ? (
              <span className="w-4 h-4 border-2 border-[#006c49] border-t-transparent rounded-full animate-spin"></span>
            ) : (
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 48 48">
                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
                <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
                <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
              </svg>
            )}
            <span>ເຂົ້າສູ່ລະບົບດ້ວຍ Google (Sign in with Google)</span>
          </button>
          <p className="text-[10px] text-gray-500 text-center">
            ເພື່ອອະນຸຍາດໃຫ້ແອັບບັນທຶກຮູບລົງໃນໂຟນເດີ Google Drive ຂອງທ່ານໄດ້ໂດຍກົງ
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          {/* User profile row */}
          <div className="flex items-center justify-between bg-[#ecfdf5] rounded-xl px-3 py-2 border border-emerald-200/80">
            <div className="flex items-center gap-2 min-w-0">
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName || 'Google user'}
                  className="w-7 h-7 rounded-full object-cover border border-emerald-400"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-[#006c49] text-white text-[12px] font-bold flex items-center justify-center">
                  {(user.displayName || user.email || 'G')[0].toUpperCase()}
                </div>
              )}
              <div className="flex flex-col min-w-0">
                <span className="font-bold text-[12px] text-[#131b2e] truncate">
                  {user.displayName || 'Google Account'}
                </span>
                <span className="text-[10px] text-gray-500 truncate">{user.email}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={handleSignOut}
              className="text-[11px] font-semibold text-gray-500 hover:text-red-600 px-2 py-1 rounded hover:bg-white transition-colors shrink-0"
            >
              ອອກຈາກລະບົບ
            </button>
          </div>

          {/* Upload Button */}
          <button
            type="button"
            onClick={handleUploadCurrentPhoto}
            disabled={isUploading || !currentPhotoUrl}
            className="w-full py-2.5 px-4 bg-[#006c49] hover:bg-[#005236] text-white font-display font-bold text-[13px] rounded-xl flex items-center justify-center gap-2 shadow-xs active:scale-98 transition-all disabled:opacity-50"
          >
            {isUploading ? (
              <>
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                <span>ກຳລັງອັບໂຫຼດຮູບລົງ Google Drive...</span>
              </>
            ) : (
              <>
                <span className="material-symbols-outlined text-[18px]">cloud_upload</span>
                <span>ບັນທຶກຮູບໜ້າຮ້ານລົງ Drive ນີ້ດຽວນີ້</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Upload Success Banner */}
      {lastUploaded && (
        <div className="bg-emerald-50 rounded-xl p-2.5 border border-emerald-300 flex items-center justify-between gap-2 text-[11px]">
          <div className="flex items-center gap-1.5 text-[#006c49] font-medium min-w-0">
            <span className="material-symbols-outlined text-[16px] text-[#10b981] shrink-0">check_circle</span>
            <span className="truncate">ບັນທຶກແລ້ວ: {lastUploaded.name}</span>
          </div>
          {lastUploaded.webViewLink && (
            <a
              href={lastUploaded.webViewLink}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#006c49] font-bold underline shrink-0 hover:text-emerald-800"
            >
              ເປີດເບິ່ງຮູບ ↗
            </a>
          )}
        </div>
      )}

      {/* Recent Uploaded Files in Folder */}
      {recentFiles.length > 0 && (
        <div className="pt-1 border-t border-gray-100 flex flex-col gap-1.5">
          <div className="flex items-center justify-between text-[11px] font-bold text-gray-700">
            <span>ຮູບທີ່ບັນທຶກໃນໂຟນເດີນີ້ ({recentFiles.length}):</span>
            <button
              onClick={() => token && fetchRecentFiles(token)}
              className="text-[10px] text-gray-500 hover:text-[#006c49] flex items-center gap-0.5"
            >
              <span className="material-symbols-outlined text-[12px]">refresh</span>
              <span>ຣີເຟຣຊ</span>
            </button>
          </div>

          <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
            {recentFiles.map((file) => (
              <a
                key={file.id}
                href={file.webViewLink || `https://drive.google.com/file/d/${file.id}/view`}
                target="_blank"
                rel="noopener noreferrer"
                className="shrink-0 bg-gray-50 hover:bg-[#ecfdf5] border border-gray-200 hover:border-emerald-300 rounded-lg p-1.5 flex items-center gap-1.5 transition-colors text-[11px]"
              >
                <span className="material-symbols-outlined text-[16px] text-[#006c49]">image</span>
                <span className="truncate max-w-[120px] font-medium text-gray-700">{file.name}</span>
                <span className="material-symbols-outlined text-[12px] text-gray-400">open_in_new</span>
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
