import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

function startApp() {
  let root = document.getElementById('root');
  if (!root) {
    root = document.createElement('div');
    root.id = 'root';
    if (document.body) {
      document.body.appendChild(root);
    } else {
      document.documentElement.appendChild(root);
    }
  }
  createRoot(root).render(<App />);
}

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startApp);
  } else {
    startApp();
  }
}

