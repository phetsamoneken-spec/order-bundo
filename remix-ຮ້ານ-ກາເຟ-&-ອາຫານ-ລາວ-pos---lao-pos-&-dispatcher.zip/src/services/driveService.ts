export const DEFAULT_DRIVE_FOLDER_ID = '1JFlPMCT6FyANB_3XN7wFhaGIQK7NEU2x';

export interface DriveUploadResult {
  id: string;
  name: string;
  webViewLink?: string;
  webContentLink?: string;
  thumbnailLink?: string;
}

// Convert dataURL or image URL to Blob
export async function urlToBlob(url: string): Promise<Blob> {
  const res = await fetch(url);
  return await res.blob();
}

/**
 * Uploads a photo to the specified Google Drive folder
 */
export async function uploadPhotoToDrive(
  accessToken: string,
  imageData: string | Blob,
  fileName: string,
  folderId: string = DEFAULT_DRIVE_FOLDER_ID
): Promise<DriveUploadResult> {
  let fileBlob: Blob;
  if (typeof imageData === 'string') {
    fileBlob = await urlToBlob(imageData);
  } else {
    fileBlob = imageData;
  }

  const mimeType = fileBlob.type || 'image/jpeg';
  const cleanName = fileName.endsWith('.jpg') || fileName.endsWith('.png') ? fileName : `${fileName}.jpg`;

  // Multipart body for Google Drive v3 API
  const metadata = {
    name: cleanName,
    parents: [folderId],
    mimeType: mimeType,
    description: 'ຮູບພາບໜ້າຮ້ານ/ອໍເດີ້ ຈາກແອັບ Laos POS WhatsApp',
  };

  const boundary = '-------314159265358979323846';
  const delimiter = `\r\n--${boundary}\r\n`;
  const closeDelimiter = `\r\n--${boundary}--`;

  const metadataPart = `${delimiter}Content-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(metadata)}`;
  const fileHeaderPart = `${delimiter}Content-Type: ${mimeType}\r\n\r\n`;

  const blobPart1 = new Blob([metadataPart], { type: 'text/plain' });
  const blobPart2 = new Blob([fileHeaderPart], { type: 'text/plain' });
  const blobPart3 = fileBlob;
  const blobPart4 = new Blob([closeDelimiter], { type: 'text/plain' });

  const multipartBody = new Blob([blobPart1, blobPart2, blobPart3, blobPart4], {
    type: `multipart/related; boundary=${boundary}`,
  });

  const response = await fetch(
    'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink,webContentLink,thumbnailLink',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
      body: multipartBody,
    }
  );

  if (!response.ok) {
    const errorJson = await response.json().catch(() => null);
    const errorMsg = errorJson?.error?.message || response.statusText;
    throw new Error(`Google Drive Upload Error: ${errorMsg}`);
  }

  const data: DriveUploadResult = await response.json();
  return data;
}

/**
 * List files uploaded to this folder
 */
export async function listFolderFiles(
  accessToken: string,
  folderId: string = DEFAULT_DRIVE_FOLDER_ID
): Promise<DriveUploadResult[]> {
  try {
    const query = encodeURIComponent(`'${folderId}' in parents and trashed = false`);
    const response = await fetch(
      `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,webViewLink,webContentLink,thumbnailLink,createdTime)&orderBy=createdTime desc&pageSize=10`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    if (!response.ok) {
      return [];
    }

    const data = await response.json();
    return data.files || [];
  } catch (err) {
    console.error('Failed to list folder files:', err);
    return [];
  }
}
