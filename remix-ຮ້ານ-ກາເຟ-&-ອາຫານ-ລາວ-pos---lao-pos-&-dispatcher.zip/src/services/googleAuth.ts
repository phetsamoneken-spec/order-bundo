import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User,
  signOut,
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App singleton safely (supports offline and file:// mode without crashing)
let app: any = null;
let auth: any = null;
try {
  app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
  auth = getAuth(app);
} catch (err) {
  console.warn('Firebase initialization skipped/failed (offline/file mode):', err);
}
export { auth };

export const SCOPES = ['https://www.googleapis.com/auth/drive.file'];

let provider: GoogleAuthProvider | null = null;
try {
  provider = new GoogleAuthProvider();
  SCOPES.forEach((scope) => provider?.addScope(scope));
  provider.setCustomParameters({
    prompt: 'select_account',
  });
} catch (e) {
  console.warn('GoogleAuthProvider init failed:', e);
}

// Flag to track ongoing sign in popup
let isSigningIn = false;
// In-memory cache for access token (NEVER store in localStorage or sessionStorage per security guidelines)
let cachedAccessToken: string | null = null;

export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  if (!auth) {
    if (onAuthFailure) onAuthFailure();
    return () => {};
  }
  try {
    return onAuthStateChanged(auth, async (user: User | null) => {
      if (user) {
        if (cachedAccessToken) {
          if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
        } else if (!isSigningIn) {
          // Token was lost on refresh, user may need to re-authenticate for Drive access
          cachedAccessToken = null;
          if (onAuthFailure) onAuthFailure();
        }
      } else {
        cachedAccessToken = null;
        if (onAuthFailure) onAuthFailure();
      }
    });
  } catch (err) {
    console.warn('onAuthStateChanged error:', err);
    if (onAuthFailure) onAuthFailure();
    return () => {};
  }
};

export const googleSignIn = async (): Promise<{ user: User; accessToken: string }> => {
  if (!auth || !provider) {
    throw new Error('Google Drive API ຕ້ອງການການເຊື່ອມຕໍ່ອິນເຕີເນັດ ແລະ ໂປຣໂຕຄອນ HTTP/HTTPS');
  }
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('ບໍ່ສາມາດຮັບ Access Token ຈາກ Google ໄດ້');
    }

    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Sign In Error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = async (): Promise<string | null> => {
  return cachedAccessToken;
};

export const setAccessTokenInMemory = (token: string | null) => {
  cachedAccessToken = token;
};

export const googleLogout = async () => {
  if (auth) {
    try {
      await signOut(auth);
    } catch {}
  }
  cachedAccessToken = null;
};
