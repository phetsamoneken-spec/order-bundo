const fs = require('fs');
const path = require('path');

const distHtmlPath = path.resolve(__dirname, '../dist/index.html');
if (!fs.existsSync(distHtmlPath)) {
  console.error('dist/index.html not found!');
  process.exit(1);
}

let html = fs.readFileSync(distHtmlPath, 'utf8');

// 1. Remove modulepreload polyfill fetch logic
html = html.replace(/\(function\(\)\{let e=document\.createElement\(`link`\)\.relList;[\s\S]*?fetch\(e\.href,n\)\}\}\)\(\);/g, '');

// 2. Extract the inlined script
const scriptRegex = /<script\b[^>]*>([\s\S]*?)<\/script>/i;
const scriptMatch = html.match(scriptRegex);

if (scriptMatch) {
  const fullScriptTag = scriptMatch[0];
  let scriptContent = scriptMatch[1];

  // Remove the script from head / wherever it was
  html = html.replace(fullScriptTag, '');

  // 3. Ensure <div id="root"></div> exists in <body>
  if (!html.includes('id="root"')) {
    html = html.replace(/<body[^>]*>/i, '$&\n    <div id="root"></div>');
  }

  // 4. Place clean classic <script> at the bottom of <body> AFTER <div id="root"></div>
  const cleanScriptTag = `\n    <script>\n${scriptContent}\n    <\/script>\n  </body>`;
  html = html.replace(/<\/body>/i, cleanScriptTag);
}

// 5. Clean up any remaining type="module" or crossorigin
html = html.replace(/<script\s+type="module"\s+crossorigin>/gi, '<script>');
html = html.replace(/<script\s+type="module">/gi, '<script>');
html = html.replace(/\s+crossorigin="?[^">]*"?/gi, '');

// Write back to dist/index.html
fs.writeFileSync(distHtmlPath, html);
console.log('Processed dist/index.html: converted to classic script at bottom of body after #root');

// Copy to single_file_index.html in root
const singleFilePath = path.resolve(__dirname, '../single_file_index.html');
fs.writeFileSync(singleFilePath, html);
console.log('Saved to single_file_index.html');

// Copy to public directory
const publicDir = path.resolve(__dirname, '../public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}
fs.writeFileSync(path.join(publicDir, 'lao_pos_app.html'), html);
fs.writeFileSync(path.join(publicDir, 'single_file_index.html'), html);
fs.writeFileSync(path.join(publicDir, 'index.html'), html);
console.log('Copied to public/lao_pos_app.html, public/single_file_index.html, and public/index.html');
